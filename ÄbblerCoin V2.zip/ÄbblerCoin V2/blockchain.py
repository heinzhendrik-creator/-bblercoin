import hashlib, json, time
from pathlib import Path

BASE = Path(__file__).parent.resolve()
DATA = BASE / "data"
LOGS = BASE / "logs"

def calculate_hash(index, timestamp, data, previous_hash, nonce):
    block_string = f"{index}{timestamp}{json.dumps(data, sort_keys=True)}{previous_hash}{nonce}"
    return hashlib.sha256(block_string.encode()).hexdigest()

def mine_block(index, timestamp, data, previous_hash, difficulty):
    nonce = 0
    prefix = "0" * difficulty
    start = time.time()
    while True:
        hash_result = calculate_hash(index, timestamp, data, previous_hash, nonce)
        if hash_result.startswith(prefix):
            return {
                "index": index,
                "timestamp": timestamp,
                "data": data,
                "previous_hash": previous_hash,
                "nonce": nonce,
                "hash": hash_result,
                "duration": round(time.time() - start, 2)
            }
        nonce += 1

def load_chain():
    path = DATA / "chain.json"
    try:
        return json.load(open(path)).get("chain", []) if path.exists() else []
    except:
        return []

def save_chain(chain):
    with open(DATA / "chain.json", "w") as f:
        json.dump({"chain": chain, "version": "1.0"}, f, indent=2)

def log_block(block):
    path = LOGS / "mining_log.json"
    try:
        logs = json.load(open(path)) if path.exists() else []
    except:
        logs = []
    logs.append({
        "timestamp": block["timestamp"],
        "hash": block["hash"],
        "nonce": block["nonce"],
        "duration": block["duration"]
    })
    with open(path, "w") as f:
        json.dump(logs, f, indent=2)