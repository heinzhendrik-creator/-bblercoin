import json, platform, requests
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).parent.resolve()
CONFIG = BASE / "config"
LOGS = BASE / "logs"
DATA = BASE / "data"

def create_file(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(content, f, indent=2)

def get_location():
    try:
        res = requests.get("https://ipinfo.io/json")
        data = res.json()
        country = data.get("country", "").lower()
        location = {
            "ip": data.get("ip", ""),
            "city": data.get("city", ""),
            "region": data.get("region", ""),
            "country": country,
            "bidding_zone": "DE-LU" if country == "de" else "EU"
        }
    except:
        location = {"ip":"unknown","city":"unknown","region":"unknown","country":"unknown","bidding_zone":"EU"}
    create_file(CONFIG / "location.json", location)
    return location

def get_spot_price(bzn, country):
    if country in ["de", "germany", "deutschland"]:
        price = 35.0
    else:
        try:
            url = f"https://api.energy-charts.info/price?bzn={bzn}&start=2025-11-05"
            res = requests.get(url)
            data = res.json()
            price = round(data["price"][-1] / 10, 2)
        except:
            price = 30.0
    create_file(CONFIG / "energy.json", {"strompreis_ct_kwh": price})
    return price

def check_cpu():
    cpu_info = platform.processor().lower()
    if not cpu_info or cpu_info == "unknown":
        cpu_info = platform.uname().processor.lower()
    if not cpu_info or cpu_info == "unknown":
        cpu_info = platform.machine().lower()
    print(f"🖥️ CPU erkannt: {cpu_info}")
    return cpu_info

def calculate_difficulty(strompreis, cpu_info):
    base = 0
    if strompreis < 40: base += 1
    if strompreis < 30: base += 1
    if strompreis < 20: base += 1
    if strompreis < 10: base += 1
    if any(x in cpu_info for x in ["i7", "i9", "ryzen", "threadripper", "xeon", "epyc", "core", "intel", "amd", "family 6"]):
        base += 1
    return min(base, 5)

def main():
    location = get_location()
    strompreis = get_spot_price(location["bidding_zone"], location["country"])
    cpu_info = check_cpu()
    difficulty = calculate_difficulty(strompreis, cpu_info)

    create_file(CONFIG / "config.json", {
        "difficulty": difficulty,
        "eco_mode": True,
        "scene_mode": True,
        "strompreis_modus": "auto"
    })

    create_file(LOGS / "setup_log.json", {
        "timestamp": datetime.utcnow().isoformat(),
        "difficulty": difficulty,
        "strompreis_ct_kwh": strompreis,
        "cpu_info": cpu_info,
        "location": location
    })

    create_file(DATA / "chain.json", {"chain": [], "version": "1.0"})

    print(f"✅ Setup abgeschlossen – Difficulty: {difficulty} | Strompreis: {strompreis} ct/kWh")

if __name__ == "__main__":
    main()