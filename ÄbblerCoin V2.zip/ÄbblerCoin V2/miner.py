import json, time
from datetime import datetime
from pathlib import Path
from blockchain import mine_block, load_chain, save_chain, log_block

BASE = Path(__file__).parent.resolve()
CONFIG = BASE / "config"
LOGS = BASE / "logs"

def load_difficulty():
    path = CONFIG / "config.json"
    try:
        return json.load(open(path)).get("difficulty", 2)
    except:
        return 2

def save_difficulty(new_diff):
    path = CONFIG / "config.json"
    try:
        config = json.load(open(path))
        config["difficulty"] = new_diff
        with open(path, "w") as f:
            json.dump(config, f, indent=2)
    except:
        print("⚠️ Difficulty konnte nicht gespeichert werden.")

def show_status():
    try:
        location = json.load(open(CONFIG / "location.json"))
        energy = json.load(open(CONFIG / "energy.json"))
        cpu_info = json.load(open(LOGS / "setup_log.json")).get("cpu_info", "unknown")
    except:
        location, energy, cpu_info = {}, {}, "unknown"

    cpu_ok = "✅ erlaubt" if any(x in cpu_info for x in [
        "i7", "i9", "ryzen", "core", "threadripper", "intel", "amd", "family 6"
    ]) else "❌ nicht erlaubt"

    print(f"""
============================================
🌍 Standort: {location.get('city','?')}, {location.get('region','?')} ({location.get('country','?')})
🖥️ CPU: {cpu_info} → {cpu_ok}
⚡ Strompreis: {energy.get('strompreis_ct_kwh','??')} ct/kWh
============================================
""")

def main():
    show_status()
    while True:
        difficulty = load_difficulty()
        chain = load_chain()
        index = len(chain) + 1
        timestamp = datetime.utcnow().isoformat()
        data = {"miner": "Hendrik", "message": "Äbblercoin lebt!"}
        previous_hash = chain[-1]["hash"] if chain else "0" * 64

        print(f"⛏️ Mining gestartet mit Difficulty {difficulty}...")
        block = mine_block(index, timestamp, data, previous_hash, difficulty)

        print(f"✅ Block gefunden! Nonce: {block['nonce']} | Hash: {block['hash']}")
        print(f"⏱️ Dauer: {block['duration']} Sekunden")

        # Dynamische Difficulty ohne Obergrenze
        duration = block["duration"]
        new_diff = difficulty

        if duration < 0.5:
            new_diff += 1
            print("⚡ Zu schnell – Difficulty erhöht!")
        elif duration > 5 and difficulty > 1:
            new_diff -= 1
            print("🐢 Zu langsam – Difficulty gesenkt!")

        if new_diff != difficulty:
            save_difficulty(new_diff)
            print(f"🎯 Neue Difficulty: {new_diff}")
        else:
            print(f"🎯 Difficulty bleibt bei: {difficulty}")

        chain.append(block)
        save_chain(chain)
        log_block(block)

        print("🍏 Block gespeichert – nächster Block wird vorbereitet...\n")
        time.sleep(1)

if __name__ == "__main__":
    main()